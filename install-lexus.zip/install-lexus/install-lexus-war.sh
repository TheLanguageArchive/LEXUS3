#!/bin/bash
set -u
set -e
cp lexus-webapp-$1.war /lat/webapps/Lexus-webapp-$1.war
su -c "./install-lexus-war-root.sh $1"
rm /lat/webapps/Lexus-webapp-$1.war
