#!/bin/bash
set -u
set -e
cd /lat/tomcat-lexical
bin/tomcat-lexical stop
pushd /lat/webapps/
set +e ; rm -fr lexus-* ; set -e
mkdir lexus-$1
pushd lexus-$1
unzip ../Lexus-webapp-$1.war
chown -R webuser.corpman *
popd
set +e ; rm lexus3; set -e
ln -s lexus-$1 lexus3
popd
set +e ; rm -r work/Catalina/localhost/lex_lexus ; set -e
bin/tomcat-lexical start