#!/bin/bash
set -u
set -e
cp webapp-$1.war /lat/webapps/
su -c "install-lexus-war-root.sh $1"
rm /lat/webapps/webapp-$1.war
