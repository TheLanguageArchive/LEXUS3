#!/bin/bash
set -u
set -e
cd /lat/tomcat-lexical
bin/tomcat-lexical stop
pushd /lat/webapps/
set +e ; rm -fr lexuscc-$1 ; set -e
mkdir lexuscc-$1
pushd lexuscc-$1
unzip ../webapp-$1.war
chown -R webuser.corpman *
popd
set +e ; rm lexuscc; set -e
ln -s lexuscc-$1 lexuscc
popd
set +e ; rm -r work/Catalina/localhost/lex_lexuscc ; set -e
bin/tomcat-lexical start
